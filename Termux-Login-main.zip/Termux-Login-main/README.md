
# COPYRIGHT
**Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for "fair use" for purposes such as criticism, comment, news reporting, teaching, scholarship, and research. Fair use is a use permitted by copyright statute that might otherwise be infringing. Non-profit, educational or personal use tips the balance in favor of fair use. No copyright infringement intended.**
# IT WILL UPGRADE
**UPDATE VERSION WILL COME Soon **
#
REMOVE LOCK FUNCTIONS
        &
FORGET PASSWORD
``
#
# Termux-Login 


**Usage**
This script is for security or lock in termux



# Commands

``apt update``

``apt install git ``

``git clone`` https://github.com/M4ND33P-M4L4K4R143/Termux-Login

``cd Termux-Login``

``chmod +x setup.sh login.sh``

``bash setup.sh``

``bash login.sh``



**Exit and Login To apply changes**
# Note

**If you entered password incorrect or name i can't help you**

# Contributers
Shehzada (only)

